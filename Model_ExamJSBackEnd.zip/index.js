require('../../RealExam_JS_back_End/Exam/config/database')().then(() => {
    const config = require('../../RealExam_JS_back_End/Exam/config/config')
    const app = require('express')()
    const appString = `Server is ready, listening on port: ${config.port}...`

    require('../../RealExam_JS_back_End/Exam/config/express')(app)
    require('../../RealExam_JS_back_End/Exam/config/routes')(app)

    app.listen(config.port, console.log(appString))
})