module.exports = {
  get: {
    home(req, res, next) {
      res.render("home/home.hbs", {
        isLoggedIn: req.user !== undefined,
        username: req.user ? req.user.username : "",
      });
    }
  },
  post: {},
};
