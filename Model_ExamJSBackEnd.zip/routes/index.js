
const users = require('./users')
const home = require('./home')



module.exports = {
  

    users,
    home
    
}